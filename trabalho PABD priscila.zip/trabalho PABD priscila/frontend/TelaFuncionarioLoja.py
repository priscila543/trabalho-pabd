import tkinter as tk
from tkinter import messagebox
import sys
import os
import customtkinter

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.FuncionarioLojaBanco import FuncionarioLojaBanco

customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("dark-blue")

class TelaFuncionarioLoja:
    def __init__(self, master):
        self.master = master
        self.master.title("Funcionário da Loja")
        self.FuncionarioLoja_banco = FuncionarioLojaBanco()

        self.label_id = customtkinter.CTkLabel(master, text="ID do Funcionário:")
        self.label_id.grid(row=0, column=0, padx=5, pady=5)
        self.entry_id = customtkinter.CTkEntry(master)
        self.entry_id.grid(row=0, column=1, padx=5, pady=5)

        self.label_username = customtkinter.CTkLabel(master, text="Username:")
        self.label_username.grid(row=1, column=0, padx=5, pady=5)
        self.entry_username = customtkinter.CTkEntry(master)
        self.entry_username.grid(row=1, column=1, padx=5, pady=5)

        self.label_senha = customtkinter.CTkLabel(master, text="Senha:")
        self.label_senha.grid(row=2, column=0, padx=5, pady=5)
        self.entry_senha = customtkinter.CTkEntry(master, show='*')
        self.entry_senha.grid(row=2, column=1, padx=5, pady=5)

        self.button_Login = customtkinter.CTkButton(master, text="Login", command=self.fazer_Login)
        self.button_Login.grid(row=3, columnspan=2, pady=5)

        self.button_home = customtkinter.CTkButton(master, text="Abrir Home", state=tk.DISABLED, command=self.abrindo_tela_home)
        self.button_home.grid(row=6, columnspan=2, pady=5)

    def fazer_Login(self):
        username = self.entry_username.get()
        senha = self.entry_senha.get()

        FuncionarioLoja = self.FuncionarioLoja_banco.get_FuncionarioLoja_by_username(username)

        if FuncionarioLoja and FuncionarioLoja.senha == senha:
            messagebox.showinfo("Sucesso", "Login realizado com sucesso!")
            self.button_home.configure(state=tk.NORMAL)
        else:
            messagebox.showerror("Erro", "Username ou senha incorretos.")

    def atualizar_funcionario(self):
        id_funcionario = self.entry_id.get()
        username = self.entry_username.get()
        senha = self.entry_senha.get()

        if not all([id_funcionario, username, senha]):
            messagebox.showwarning("Atenção", "Preencha todos os campos.")
            return

        try:
            self.FuncionarioLoja_banco.atualizar_funcionario(int(id_funcionario), username, senha)
            messagebox.showinfo("Sucesso", "Funcionário atualizado com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao atualizar funcionário: {e}")

    def remover_funcionario(self):
        id_funcionario = self.entry_id.get()

        if not id_funcionario:
            messagebox.showwarning("Atenção", "Informe o ID do Funcionário.")
            return

        try:
            self.FuncionarioLoja_banco.remover_funcionario(int(id_funcionario))
            messagebox.showinfo("Sucesso", "Funcionário removido com sucesso!")
            self.limpar_campos()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao remover funcionário: {e}")

    def limpar_campos(self):
        self.entry_id.delete(0, tk.END)
        self.entry_username.delete(0, tk.END)
        self.entry_senha.delete(0, tk.END)

    def abrindo_tela_home(self):
        print("Abrindo TelaHome")
        self.master.withdraw()
        self.new_window = tk.Toplevel(self.master)

        from frontend.TelaHome import TelaHome
        TelaHome(self.new_window)
        self.new_window.protocol("WM_DELETE_WINDOW", self.voltar)

    def voltar(self):
        self.master.deiconify()

if __name__ == "__main__":
    root = tk.Tk()
    app = TelaFuncionarioLoja(root)
    root.mainloop()
