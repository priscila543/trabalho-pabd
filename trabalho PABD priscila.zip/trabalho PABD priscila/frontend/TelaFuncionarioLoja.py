import tkinter as tk  # Importa a biblioteca tkinter para criar interfaces gráficas
from tkinter import messagebox  # Importa a caixa de mensagem do tkinter
import sys
import os
import customtkinter  # Importa customtkinter para criar interfaces com estilo

# Adiciona o diretório pai ao caminho do sistema para permitir a importação de módulos
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.FuncionarioLojaBanco import FuncionarioLojaBanco  # Importa a classe FuncionarioLojaBanco do módulo backend

# Configura o tema da interface gráfica
customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("dark-blue")

class TelaFuncionarioLoja:
    def __init__(self, master):
        """
        Inicializa a classe TelaFuncionarioLoja.
        
        :param master: A janela principal da aplicação.
        """
        self.master = master  # Armazena a referência da janela principal
        self.master.title("Funcionário da Loja")  # Define o título da janela
        self.FuncionarioLoja_banco = FuncionarioLojaBanco()  # Cria uma instância da classe FuncionarioLojaBanco

        # Criação dos campos de entrada para ID do funcionário
        self.label_cod = customtkinter.CTkLabel(master, text="codigo do Funcionário:")
        self.label_cod.grid(row=0, column=0, padx=5, pady=5)  # Adiciona o rótulo à janela
        self.entry_cod = customtkinter.CTkEntry(master)  # Campo para inserir o codigo
        self.entry_cod.grid(row=0, column=1, padx=5, pady=5)  # Adiciona o campo à janela

        # Criação dos campos de entrada para o nome de usuário
        self.label_username = customtkinter.CTkLabel(master, text="Username:")
        self.label_username.grid(row=1, column=0, padx=5, pady=5)  # Adiciona o rótulo à janela
        self.entry_username = customtkinter.CTkEntry(master)  # Campo para inserir o nome de usuário
        self.entry_username.grid(row=1, column=1, padx=5, pady=5)  # Adiciona o campo à janela

        # Criação dos campos de entrada para a senha
        self.label_senha = customtkinter.CTkLabel(master, text="Senha:")
        self.label_senha.grid(row=2, column=0, padx=5, pady=5)  # Adiciona o rótulo à janela
        self.entry_senha = customtkinter.CTkEntry(master, show='*')  # Campo para inserir a senha (oculta)
        self.entry_senha.grid(row=2, column=1, padx=5, pady=5)  # Adiciona o campo à janela

        # Botão para realizar o login
        self.button_Login = customtkinter.CTkButton(master, text="Login", command=self.fazer_Login)
        self.button_Login.grid(row=3, columnspan=2, pady=5)  # Adiciona o botão à janela

        # Botão para abrir a tela inicial, inicialmente desabilitado
        self.button_joia = customtkinter.CTkButton(master, text="Abrir Tela Joia", state=tk.DISABLED, command=self.abrindo_tela_joia)
        self.button_joia.grid(row=6, columnspan=2, pady=5)  # Adiciona o botão à janela

    def fazer_Login(self):
        """Realiza o login do funcionário usando o nome de usuário e senha."""
        username = self.entry_username.get()  # Obtém o nome de usuário do campo
        senha = self.entry_senha.get()  # Obtém a senha do campo

        # Busca o funcionário no banco de dados usando o nome de usuário
        FuncionarioLoja = self.FuncionarioLoja_banco.get_FuncionarioLoja_by_username(username)

        # Verifica se o funcionário existe e se a senha está correta
        if FuncionarioLoja and FuncionarioLoja.senha == senha:
            messagebox.showinfo("Sucesso", "Login realizado com sucesso!")  # Exibe mensagem de sucesso
            self.button_joia.configure(state=tk.NORMAL)  # Habilita o botão de abrir a home
        else:
            messagebox.showerror("Erro", "Username ou senha incorretos.")  # Exibe mensagem de erro

    def atualizar_funcionario(self):
        """Atualiza os dados do funcionário no banco de dados."""
        cod_funcionario = self.entry_cod.get()  # Obtém o codigo do funcionário
        username = self.entry_username.get()  # Obtém o nome de usuário
        senha = self.entry_senha.get()  # Obtém a senha

        # Verifica se todos os campos estão preenchidos
        if not all([cod_funcionario, username, senha]):
            messagebox.showwarning("Atenção", "Preencha todos os campos.")  # Exibe aviso se campos estiverem vazios
            return

        try:
            # Atualiza os dados do funcionário no banco de dados
            self.FuncionarioLoja_banco.atualizar_funcionario(int(cod_funcionario), username, senha)
            messagebox.showinfo("Sucesso", "Funcionário atualizado com sucesso!")  # Mensagem de sucesso
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao atualizar funcionário: {e}")  # Mensagem de erro

    def remover_funcionario(self):
        """Remove um funcionário do banco de dados usando o ID."""
        cod_funcionario = self.entry_cod.get()  # Obtém o codigo do funcionário

        if not cod_funcionario:
            messagebox.showwarning("Atenção", "Informe o cod do Funcionário.")  # Aviso se o codigo não for informado
            return

        try:
            # Remove o funcionário do banco de dados
            self.FuncionarioLoja_banco.remover_funcionario(int(cod_funcionario))
            messagebox.showinfo("Sucesso", "Funcionário removido com sucesso!")  # Mensagem de sucesso
            self.limpar_campos()  # Limpa os campos de entrada
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao remover funcionário: {e}")  # Mensagem de erro

    def limpar_campos(self):
        """Limpa todos os campos de entrada."""
        self.entry_cod.delete(0, tk.END)  # Limpa o campo do codigo
        self.entry_username.delete(0, tk.END)  # Limpa o campo do nome de usuário
        self.entry_senha.delete(0, tk.END)  # Limpa o campo da senha

    def abrindo_tela_joia(self):
        """Abre a tela inicial da aplicação."""
        print("Abrindo TelaJoia")  # Mensagem no console
        self.master.withdraw()  # Esconde a janela atual
        self.new_window = tk.Toplevel(self.master)  # Cria uma nova janela

        # Importa a classe TelaJoia e a instancia
        from frontend.TelaJoia import TelaJoia
        TelaJoia(self.new_window)  # Abre a tela inicial
        self.new_window.protocol("WM_DELETE_WINDOW", self.voltar)  # Configura o protocolo para voltar à tela anterior

    def voltar(self):
        """Retorna à janela anterior."""
        self.master.deiconify()  # Mostra a janela principal novamente

if __name__ == "__main__":
    root = tk.Tk()  # Cria a janela principal
    app = TelaFuncionarioLoja(root)  # Instancia a tela de funcionário da loja
    root.mainloop()  # Inicia o loop da interface gráfica
