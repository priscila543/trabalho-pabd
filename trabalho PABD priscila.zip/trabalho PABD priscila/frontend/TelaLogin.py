# Importando bibliotecas necessárias
import tkinter as tk
from tkinter import messagebox  # Para exibir caixas de mensagem
import sys
import os
import customtkinter  # Biblioteca para interface gráfica customizada

# Adicionando o caminho do diretório pai para o sistema, permitindo a importação de módulos
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importando classes necessárias de outros módulos
from backend.ClienteBanco import ClienteBanco  # Classe para gerenciar clientes
from frontend.TelaLoja import TelaLoja  # Classe para a tela da loja

# Configurando o tema da interface
customtkinter.set_appearance_mode("dark")  # Modo escuro
customtkinter.set_default_color_theme("dark-blue")  # Tema azul escuro

# Inicializando a classe ClienteBanco para gerenciar clientes
clienteBanco = ClienteBanco()

# Função para verificar se o login é válido
def verificar_login():
    # Obtendo os valores digitados nos campos de entrada
    nome_digitado = nome.get()
    senha_digitada = senha.get()
    
    # Buscando o cliente pelo nome
    cliente = clienteBanco.get_cliente_pelo_nome(nome_digitado)

    # Verificando se o cliente existe e se a senha está correta
    if cliente is not None and cliente.senha == senha_digitada:
        messagebox.showinfo("Login", "Login bem-sucedido!")  # Mensagem de sucesso
        abrindo_tela_Loja()  # Chama a função para abrir a tela da loja
    else: 
        messagebox.showerror("Login", "Nome do cliente ou senha incorretos.")  # Mensagem de erro

# Função para abrir a tela da loja
def abrindo_tela_Loja():
    print("Abrindo TelaLoja")  # Log no console para indicar que a tela da loja está sendo aberta
    janela.withdraw()  # Esconde a janela de login
    new_window = tk.Toplevel(janela)  # Cria uma nova janela para a loja
    tela_loja = TelaLoja(new_window)  # Inicializa a tela da loja

# Configurando a janela principal da aplicação
janela = customtkinter.CTk() 
janela.geometry("590x300")  # Define o tamanho da janela
janela.title("Tela de Login")  # Define o título da janela

# Criando e posicionando os elementos da interface
texto = customtkinter.CTkLabel(janela, text="Fazer Login") 
texto.pack(padx=10, pady=10)  # Adiciona um rótulo

nome = customtkinter.CTkEntry(janela, placeholder_text="Seu nome") 
nome.pack(padx=10, pady=10)  # Campo para digitar o nome

senha = customtkinter.CTkEntry(janela, placeholder_text="Sua senha", show="*")
senha.pack(padx=10, pady=10)  # Campo para digitar a senha, com caracteres ocultos

# Botão de login que chama a função de verificação ao ser clicado
botao = customtkinter.CTkButton(janela, text="Login", command=verificar_login)
botao.pack(padx=10, pady=10)  # Adiciona o botão

# Inicia o loop principal da interface gráfica
janela.mainloop()
