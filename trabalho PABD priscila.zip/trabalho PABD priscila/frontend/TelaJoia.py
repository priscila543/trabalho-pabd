import tkinter as tk  # Importa a biblioteca tkinter para criar interfaces gráficas
import sys
import os
import customtkinter as ctk  # Importa customtkinter, que é uma versão estilizada do tkinter

# Adiciona o diretório pai ao caminho do sistema para permitir a importação de módulos
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.JoiaBanco import JoiaBanco  # Importa a classe JoiaBanco do módulo backend

# Configura o tema da interface gráfica
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

class TelaJoia:
    def __init__(self, root):
        """
        Inicializa a classe TelaJoia.
        
        :param root: A janela principal da aplicação.
        """
        self.root = root  # Armazena a referência da janela principal
        self.joia_banco = JoiaBanco()  # Cria uma instância da classe JoiaBanco
        self.setup_ui()  # Chama o método para configurar a interface

    def setup_ui(self):
        """Configura os elementos da interface gráfica da tela principal."""
        # Cria um rótulo de boas-vindas
        label = ctk.CTkLabel(self.root, text="Seja bem-vindo a Tela Joia")
        label.pack(pady=20)  # Adiciona o rótulo à janela com espaçamento vertical

        # Botão para cadastrar uma nova joia
        button_cadastrar = ctk.CTkButton(self.root, text="Cadastrar Joia", command=self.open_new_window)
        button_cadastrar.pack(pady=10)  # Adiciona o botão à janela

        # Botão para acessar a lista de joias
        button_acessar_joias = ctk.CTkButton(self.root, text="Acessar Joias", command=self.open_joias_window)
        button_acessar_joias.pack(pady=10)  # Adiciona o botão à janela

    def open_new_window(self):
        """Abre uma nova janela para cadastrar uma nova joia."""
        self.run()  # Chama o método que cria a janela de cadastro

    def open_joias_window(self):
        """Abre uma nova janela para acessar a lista de joias."""
        self.run_joias()  # Chama o método que cria a janela de lista de joias

    def atualizar_Joia(self):
        """
        Atualiza os dados da joia selecionada na lista.
        """
        if not hasattr(self, 'listbox_Joias'):
            print("A lista de joias não está disponível.")
            return

        selected_index = self.listbox_Joias.curselection()  # Obtém o índice da joia selecionada
        if selected_index:
            try:
                selected_item = self.listbox_Joias.get(selected_index)  # Obtém o item selecionado
                partes = selected_item.split(" - ")  # Divide o item em partes

                if len(partes) < 4: 
                    print("Formato inesperado do item selecionado.")
                    return

                id_joia = int(partes[0].split(":")[1].strip())  # Extrai o ID da joia

                # Verifica se os campos de entrada estão disponíveis
                if not (self.entry_nome.winfo_exists() and self.entry_tipo.winfo_exists() and
                        self.entry_quantidade.winfo_exists() and self.entry_artesao.winfo_exists()):
                    print("Alguma das entradas não está disponível.")
                    return

                # Obtém os novos dados da joia
                novo_nome = self.entry_nome.get()
                novo_tipo = self.entry_tipo.get()
                nova_quantidade = self.entry_quantidade.get()
                novo_artesao = self.entry_artesao.get()

                # Verifica se os dados estão corretos e atualiza a joia
                if novo_nome and novo_tipo and nova_quantidade.isdigit() and novo_artesao:
                    self.joia_banco.atualizar_dados(id_joia, novo_nome, int(nova_quantidade), novo_tipo, novo_artesao)
                    self.atualizar_lista_Joias()  # Atualiza a lista de joias
                    self.limpar_campos()  # Limpa os campos de entrada
                else:
                    print("Preencha todos os campos corretamente.")
            except (IndexError, ValueError) as e:
                print(f"Erro ao processar a seleção: {e}")
        else:
            print("Selecione uma joia para atualizar.")

    def remover_Joia(self):
        """Remove a joia selecionada da lista."""
        if not hasattr(self, 'listbox_Joias'):
            print("A lista de joias não está disponível.")
            return

        selected_index = self.listbox_Joias.curselection()  # Obtém o índice da joia selecionada
        if selected_index:
            try:
                selected_item = self.listbox_Joias.get(selected_index)  # Obtém o item selecionado
                partes = selected_item.split(" - ")  # Divide o item em partes

                if len(partes) < 4:
                    print("Formato inesperado do item selecionado.")
                    return

                id_joia = int(partes[0].split(":")[1].strip())  # Extrai o ID da joia
                self.joia_banco.remover_Joia(id_joia)  # Remove a joia do banco
                self.atualizar_lista_Joias()  # Atualiza a lista de joias
                self.limpar_campos()  # Limpa os campos de entrada
            except (IndexError, ValueError) as e:
                print(f"Erro ao processar a seleção: {e}")
        else:
            print("Selecione uma joia para remover.")

    def run(self):
        """Cria a janela de cadastro de joias."""
        mywindow2 = tk.Toplevel()  # Cria uma nova janela
        mywindow2.geometry("800x400")  # Define o tamanho da janela
        mywindow2.title("Cadastro de Joia")  # Define o título da janela

        self.listbox = tk.Listbox(mywindow2)  # Cria uma listbox para mostrar tipos de joias
        self.listbox.grid(row=0, column=0)  # Adiciona a listbox à janela
        self.complete_lista_tipo_Joia()  # Preenche a listbox com tipos de joias

        button = ctk.CTkButton(mywindow2, text='Cadastrar Joia', command=self.buttonPress)  # Botão para cadastrar
        button.grid(row=0, column=1)  # Adiciona o botão à janela

        # Cria campos de entrada para os dados da joia
        self.entry_id = ctk.CTkEntry(mywindow2, placeholder_text="ID da loja")
        self.entry_id.grid(row=1, column=1)

        self.entry_nome = ctk.CTkEntry(mywindow2, placeholder_text="Nome")
        self.entry_nome.grid(row=2, column=1)

        self.entry_quantidade = ctk.CTkEntry(mywindow2, placeholder_text="Quantidade")
        self.entry_quantidade.grid(row=3, column=1)

        self.entry_tipo = ctk.CTkEntry(mywindow2, placeholder_text="Tipo")
        self.entry_tipo.grid(row=4, column=1)

        self.entry_id_joia = ctk.CTkEntry(mywindow2, placeholder_text="ID joia")
        self.entry_id_joia.grid(row=5, column=1)

        self.entry_artesao = ctk.CTkEntry(mywindow2, placeholder_text="Artesão")
        self.entry_artesao.grid(row=6, column=1)

    def run_joias(self):
        """Cria a janela que exibe a lista de joias."""
        mywindow_joias = tk.Toplevel()  # Cria uma nova janela
        mywindow_joias.geometry("800x400")  # Define o tamanho da janela
        mywindow_joias.title("Lista de Joias")  # Define o título da janela

        self.listbox_Joias = tk.Listbox(mywindow_joias)  # Cria uma listbox para mostrar joias
        lista_joias = self.joia_banco.get_all_Joia()  # Obtém todas as joias do banco
        for joia in lista_joias:
            # Insere cada joia na listbox
            self.listbox_Joias.insert(tk.END, f"ID: {joia.id_joia} - Nome: {joia.nome} - Tipo: {joia.tipo} - Quantidade: {joia.quantidade}")

        self.listbox_Joias.pack(pady=20)  # Adiciona a listbox à janela

        # Botão para atualizar a joia selecionada
        button_atualizar = ctk.CTkButton(mywindow_joias, text="Atualizar Joia", command=self.atualizar_Joia)
        button_atualizar.pack(pady=10)

        # Botão para remover a joia selecionada
        button_remover = ctk.CTkButton(mywindow_joias, text="Remover Joia", command=self.remover_Joia)
        button_remover.pack(pady=10)

    def buttonPress(self):
        """Cadastra uma nova joia com os dados informados pelo usuário."""
        if not self.entry_id_loja.winfo_exists() or not self.entry_nome.winfo_exists():
            print("A janela de cadastro foi fechada.")
            return

        # Obtém os dados da joia dos campos de entrada
        id_loja = self.entry_id_loja.get()
        nome = self.entry_nome.get()
        quantidade = self.entry_quantidade.get()
        tipo = self.entry_tipo.get()
        artesao = self.entry_artesao.get()
        id_joia = self.entry_id.get()

        # Verifica se todos os campos estão preenchidos
        if not all([id_loja, nome, quantidade, tipo, artesao, id_joia]):
            print("Preencha todos os campos.")
            return

        try:
            # Converte os valores para inteiros
            quantidade_int = int(quantidade)
            id_loja_int = int(id_loja)
            id_joia_int = int(id_joia)

            # Insere a nova joia no banco de dados
            self.joia_banco.insert_new_Joia(id_loja_int, nome, quantidade_int, tipo, id_joia_int, artesao)
            self.complete_lista_tipo_Joia()  # Atualiza a lista de tipos de joias
        except ValueError as e:
            print(f"Erro ao converter valores: {e}")
        except Exception as e:
            print(f"Erro ao cadastrar joia: {e}")

    def complete_lista_tipo_Joia(self):
        """Preenche a listbox com os tipos de joias disponíveis no banco de dados."""
        lista_Joias_banco_dados = self.joia_banco.get_all_Joia()  # Obtém todas as joias
        lista_tipo_Joia = sorted([joia.tipo for joia in lista_Joias_banco_dados], reverse=True)  # Ordena os tipos de joia
        self.listbox.delete(0, tk.END)  # Limpa a listbox
        for nome in lista_tipo_Joia:
            self.listbox.insert(tk.END, nome)  # Insere cada tipo de joia na listbox

    def atualizar_lista_Joias(self):
        """Atualiza a listbox com as joias disponíveis no banco de dados."""
        if hasattr(self, 'listbox_Joias'):
            self.listbox_Joias.delete(0, tk.END)  # Limpa a listbox
            lista_joias = self.joia_banco.get_all_Joia()  # Obtém todas as joias
            for joia in lista_joias:
                # Insere cada joia na listbox
                self.listbox_Joias.insert(tk.END, f"ID: {joia.id_joia} - Nome: {joia.nome} - Tipo: {joia.tipo} - Quantidade: {joia.quantidade}")

    def limpar_campos(self):
        """Limpa todos os campos de entrada na janela de cadastro."""
        self.entry_id.delete(0, tk.END)
        self.entry_nome.delete(0, tk.END)
        self.entry_quantidade.delete(0, tk.END)
        self.entry_tipo.delete(0, tk.END)
        self.entry_id_joia.delete(0, tk.END)
        self.entry_artesao.delete(0, tk.END)

if __name__ == "__main__":
    root = ctk.CTk()  # Cria a janela principal
    try:
        app = TelaJoia(root)  # Instancia a tela de joias
    except Exception as e:
        print(f"Erro ao iniciar a aplicação: {e}")
    root.mainloop()  # Inicia o loop da interface gráfica
