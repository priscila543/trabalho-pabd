import tkinter as tk
import psycopg2
from tkinter import messagebox
import sys
import os
import customtkinter as ctk

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.LojaBanco import LojaBanco

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

class TelaLoja:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerenciador de Lojas")

        self.Loja_banco = LojaBanco()
        self.Loja_banco.criar_tabela_Loja()

        self.setup_widgets()
        self.atualizar_lista_Lojas()

    def setup_widgets(self):
        ctk.CTkLabel(self.root, text="ID da Loja:").grid(row=0, column=0, pady=5)
        self.entry_id = ctk.CTkEntry(self.root)
        self.entry_id.grid(row=0, column=1, pady=5)

        ctk.CTkLabel(self.root, text="Nome da Loja:").grid(row=1, column=0, pady=5)
        self.entry_nome = ctk.CTkEntry(self.root)
        self.entry_nome.grid(row=1, column=1, pady=5)

        ctk.CTkLabel(self.root, text="Cod do Funcionário:").grid(row=2, column=0, pady=5)
        self.entry_cod = ctk.CTkEntry(self.root)
        self.entry_cod.grid(row=2, column=1, pady=5)

        ctk.CTkLabel(self.root, text="ID Joia:").grid(row=3, column=0, pady=5)
        self.entry_Joia_id = ctk.CTkEntry(self.root)
        self.entry_Joia_id.grid(row=3, column=1, pady=5)

        self.button_cadastrar = ctk.CTkButton(self.root, text="Cadastrar Loja", command=self.cadastrar_Loja)
        self.button_cadastrar.grid(row=4, columnspan=2, pady=10)

        self.listbox_Lojas = tk.Listbox(self.root)
        self.listbox_Lojas.grid(row=5, columnspan=2, pady=5)

        self.button_joias = ctk.CTkButton(self.root, text="Acessar Joias", command=self.abrir_tela_Joia)
        self.button_joias.grid(row=6, columnspan=2, pady=5)

        self.button_funcionarios = ctk.CTkButton(self.root, text="Acessar Funcionários da Loja", command=self.abrir_tela_funcionarios)
        self.button_funcionarios.grid(row=7, columnspan=2, pady=5)

        self.button_funcionarioloja = ctk.CTkButton(self.root, text="Tela Funcionário Loja", command=self.abrindo_tela_home)
        self.button_funcionarioloja.grid(row=8, columnspan=2, pady=5)

    def cadastrar_Loja(self):
        id = self.entry_id.get()
        nome = self.entry_nome.get()
        cod_funcionario = self.entry_cod.get()
        Joia_id = self.entry_Joia_id.get()

        if not all([id, nome, cod_funcionario, Joia_id]):
            messagebox.showwarning("Atenção", "Preencha todos os campos.")
            return

        if not (id.isdigit() and cod_funcionario.isdigit() and Joia_id.isdigit()):
            messagebox.showwarning("Atenção", "ID, Cod e Código da Joia devem ser numéricos.")
            return

        if not self.Loja_banco.verifica_Joia_existente(int(Joia_id)):
            messagebox.showwarning("Atenção", "ID da Joia não encontrado.")
            return

        try:
            self.Loja_banco.cadastrar_loja(int(id), nome, cod_funcionario, int(Joia_id))
            self.atualizar_lista_Lojas()
            self.limpar_campos()
            messagebox.showinfo("Sucesso", "Loja cadastrada com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao cadastrar a loja: {e}")

    def atualizar_lista_Lojas(self):
        self.listbox_Lojas.delete(0, tk.END)
        try:
            for loja in self.Loja_banco.get_all_Lojas():
                id_loja, nome_loja = loja[0], loja[1]
                self.listbox_Lojas.insert(tk.END, f"ID: {id_loja}, Nome: {nome_loja}")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao atualizar a lista das lojas: {e}")

    def abrir_tela_Joia(self):
        selected_index = self.listbox_Lojas.curselection()
        if not selected_index:
            messagebox.showwarning("Atenção", "Selecione uma Loja antes de acessar as Joias.")
            return
        
        selected_loja = self.listbox_Lojas.get(selected_index)
        try:
            id_loja = int(selected_loja.split(",")[0].split(":")[1].strip())
        except (IndexError, ValueError):
            messagebox.showerror("Erro", "A loja selecionada não contém um ID válido.")
            return

        self.abrir_nova_tela_joia(id_loja)

    def abrir_tela_funcionarios(self):
        selected_index = self.listbox_Lojas.curselection()
        if not selected_index:
            messagebox.showwarning("Atenção", "Selecione uma Loja antes de acessar os funcionários.")
            return
        
        selected_loja = self.listbox_Lojas.get(selected_index)
        try:
            id_loja = int(selected_loja.split(",")[0].split(":")[1].strip())
        except (IndexError, ValueError):
            messagebox.showerror("Erro", "A loja selecionada não contém um ID válido.")
            return

        self.exibir_funcionarios_da_loja(id_loja)

    def exibir_funcionarios_da_loja(self, id_loja):
        funcionarios = self.Loja_banco.get_funcionarios_da_loja(id_loja)

        self.nova_tela_funcionarios = ctk.CTkToplevel(self.root)
        self.nova_tela_funcionarios.title("Funcionários da Loja")

        label_titulo = ctk.CTkLabel(self.nova_tela_funcionarios, text=f"Funcionários da Loja ID: {id_loja}")
        label_titulo.pack(pady=10)

        self.listbox_funcionarios = tk.Listbox(self.nova_tela_funcionarios)
        self.listbox_funcionarios.pack(pady=10)

        for funcionario in funcionarios:
            self.listbox_funcionarios.insert(tk.END, f"ID: {funcionario[0]}, Nome: {funcionario[1]}")

        button_atualizar = ctk.CTkButton(self.nova_tela_funcionarios, text="Atualizar Funcionário", command=self.atualizar_funcionario)
        button_atualizar.pack(pady=5)

        button_remover = ctk.CTkButton(self.nova_tela_funcionarios, text="Remover Funcionário", command=self.remover_funcionario)
        button_remover.pack(pady=5)

        button_fechar = ctk.CTkButton(self.nova_tela_funcionarios, text="Fechar", command=self.nova_tela_funcionarios.destroy)
        button_fechar.pack(pady=10)

    def atualizar_funcionario(self):
        selected_index = self.listbox_funcionarios.curselection()
        if not selected_index:
            messagebox.showwarning("Atenção", "Selecione um funcionário para atualizar.")
            return
        
        funcionario_selecionado = self.listbox_funcionarios.get(selected_index)
        try:
            id_funcionario = int(funcionario_selecionado.split(",")[0].split(":")[1].strip())
        except (IndexError, ValueError):
            messagebox.showerror("Erro", "Funcionário selecionado não contém um ID válido.")
            return
        
        self.janela_atualizacao = ctk.CTkToplevel(self.nova_tela_funcionarios)
        self.janela_atualizacao.title("Atualizar Funcionário")

        ctk.CTkLabel(self.janela_atualizacao, text="Novo Nome:").grid(row=0, column=0, pady=5)
        self.entry_novo_nome = ctk.CTkEntry(self.janela_atualizacao)
        self.entry_novo_nome.grid(row=0, column=1, pady=5)

        ctk.CTkButton(self.janela_atualizacao, text="Salvar", command=lambda: self.salvar_atualizacao(id_funcionario)).grid(row=1, columnspan=2, pady=10)

    def salvar_atualizacao(self, id_funcionario):
        novo_nome = self.entry_novo_nome.get()
        if not novo_nome:
            messagebox.showwarning("Atenção", "O nome não pode ser vazio.")
            return
        try:
            self.Loja_banco.atualizar_funcionario(id_funcionario, novo_nome) 
            messagebox.showinfo("Sucesso", "Funcionário atualizado com sucesso!")
            self.nova_tela_funcionarios.destroy() 
            self.atualizar_lista_Lojas() 
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao atualizar o funcionário: {e}")

    def remover_funcionario(self):
        selected_index = self.listbox_funcionarios.curselection()
        if not selected_index:
            messagebox.showwarning("Atenção", "Selecione um funcionário para remover.")
            return
        
        funcionario_selecionado = self.listbox_funcionarios.get(selected_index)
        try:
            id_funcionario = int(funcionario_selecionado.split(",")[0].split(":")[1].strip())
        except (IndexError, ValueError):
            messagebox.showerror("Erro", "Funcionário selecionado não contém um ID válido.")
            return
        
        confirm = messagebox.askyesno("Confirmar", "Tem certeza que deseja remover este funcionário?")
        if confirm:
            try:
                self.Loja_banco.remover_funcionario(id_funcionario)  
                messagebox.showinfo("Sucesso", "Funcionário removido com sucesso!")
                self.nova_tela_funcionarios.destroy() 
                self.atualizar_lista_Lojas()  
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao remover o funcionário: {e}")

    def abrir_nova_tela_joia(self, id_loja):
        self.nova_tela_joia = ctk.CTkToplevel(self.root)
        self.nova_tela_joia.title(f"Joias da Loja ID: {id_loja}")

        label_titulo = ctk.CTkLabel(self.nova_tela_joia, text=f"Joias da Loja ID: {id_loja}")
        label_titulo.pack(pady=10)

    def limpar_campos(self):
        self.entry_id.delete(0, tk.END)
        self.entry_nome.delete(0, tk.END)
        self.entry_cod.delete(0, tk.END)
        self.entry_Joia_id.delete(0, tk.END)

    def abrindo_tela_home(self):
        print("Abrindo TelaHome")
        self.root.withdraw() 
        self.new_window = tk.Toplevel(self.root)

        from frontend.TelaHome import TelaHome  
        TelaHome(self.new_window)
        self.new_window.protocol("WM_DELETE_WINDOW", self.voltar)

    def voltar(self):
        self.root.deiconify() 

if __name__ == "__main__":
    root = ctk.CTk()
    app = TelaLoja(root)
    root.mainloop()
