import tkinter as tk
import sys
import os
import customtkinter as ctk

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.JoiaBanco import JoiaBanco

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

class TelaHome:
    def __init__(self, root):
        
        self.root = root
        self.joia_banco = JoiaBanco()
        self.setup_ui()

    def setup_ui(self):
        label = ctk.CTkLabel(self.root, text="Seja bem-vindo")
        label.pack(pady=20)

        button_cadastrar = ctk.CTkButton(self.root, text="Cadastrar Joia", command=self.open_new_window)
        button_cadastrar.pack(pady=10)

        button_acessar_joias = ctk.CTkButton(self.root, text="Acessar Joias", command=self.open_joias_window)
        button_acessar_joias.pack(pady=10)

    def open_new_window(self):
        self.run()

    def open_joias_window(self):
        self.run_joias()

    def atualizar_Joia(self):
        if not hasattr(self, 'listbox_Joias'):
            print("A lista de joias não está disponível.")
            return

        selected_index = self.listbox_Joias.curselection()
        if selected_index:
            try:
                selected_item = self.listbox_Joias.get(selected_index)
                partes = selected_item.split(" - ")

                if len(partes) < 4: 
                    print("Formato inesperado do item selecionado.")
                    return

                id_joia = int(partes[0].split(":")[1].strip())

                if not (self.entry_nome.winfo_exists() and self.entry_tipo.winfo_exists() and
                        self.entry_quantidade.winfo_exists() and self.entry_artesao.winfo_exists()):
                    print("Alguma das entradas não está disponível.")
                    return

                novo_nome = self.entry_nome.get()
                novo_tipo = self.entry_tipo.get()
                nova_quantidade = self.entry_quantidade.get()
                novo_artesao = self.entry_artesao.get()

                if novo_nome and novo_tipo and nova_quantidade.isdigit() and novo_artesao:
                    self.joia_banco.atualizar_dados(id_joia, novo_nome, int(nova_quantidade), novo_tipo, novo_artesao)
                    self.atualizar_lista_Joias()
                    self.limpar_campos()
                else:
                    print("Preencha todos os campos corretamente.")
            except (IndexError, ValueError) as e:
                print(f"Erro ao processar a seleção: {e}")
        else:
            print("Selecione uma joia para atualizar.")


    def remover_Joia(self):
        if not hasattr(self, 'listbox_Joias'):
            print("A lista de joias não está disponível.")
            return

        selected_index = self.listbox_Joias.curselection()
        if selected_index:
            try:
                selected_item = self.listbox_Joias.get(selected_index)
                partes = selected_item.split(" - ")

                if len(partes) < 4:
                    print("Formato inesperado do item selecionado.")
                    return

                id_joia = int(partes[0].split(":")[1].strip())
                self.joia_banco.remover_Joia(id_joia)
                self.atualizar_lista_Joias()
                self.limpar_campos()
            except (IndexError, ValueError) as e:
                print(f"Erro ao processar a seleção: {e}")
        else:
            print("Selecione uma joia para remover.")

    def run(self):
        mywindow2 = tk.Toplevel()
        mywindow2.geometry("800x400")
        mywindow2.title("Cadastro de Joia")

        self.listbox = tk.Listbox(mywindow2)
        self.listbox.grid(row=0, column=0)
        self.complete_lista_tipo_Joia()

        button = ctk.CTkButton(mywindow2, text='Cadastrar Joia', command=self.buttonPress)
        button.grid(row=0, column=1)

        self.entry_id_loja = ctk.CTkEntry(mywindow2, placeholder_text="ID da loja")
        self.entry_id_loja.grid(row=1, column=1)

        self.entry_nome = ctk.CTkEntry(mywindow2, placeholder_text="Nome")
        self.entry_nome.grid(row=2, column=1)

        self.entry_quantidade = ctk.CTkEntry(mywindow2, placeholder_text="Quantidade")
        self.entry_quantidade.grid(row=3, column=1)

        self.entry_tipo = ctk.CTkEntry(mywindow2, placeholder_text="Tipo")
        self.entry_tipo.grid(row=4, column=1)

        self.entry_id = ctk.CTkEntry(mywindow2, placeholder_text="ID joia")
        self.entry_id.grid(row=5, column=1)

        self.entry_artesao = ctk.CTkEntry(mywindow2, placeholder_text="Artesão")
        self.entry_artesao.grid(row=6, column=1)

    def run_joias(self):
        mywindow_joias = tk.Toplevel()
        mywindow_joias.geometry("800x400")
        mywindow_joias.title("Lista de Joias")

        self.listbox_Joias = tk.Listbox(mywindow_joias)
        lista_joias = self.joia_banco.get_all_Joia()
        for joia in lista_joias:
            self.listbox_Joias.insert(tk.END, f"ID: {joia.id_joia} - Nome: {joia.nome} - Tipo: {joia.tipo} - Quantidade: {joia.quantidade}")

        self.listbox_Joias.pack(pady=20)

        button_atualizar = ctk.CTkButton(mywindow_joias, text="Atualizar Joia", command=self.atualizar_Joia)
        button_atualizar.pack(pady=10)

        button_remover = ctk.CTkButton(mywindow_joias, text="Remover Joia", command=self.remover_Joia)
        button_remover.pack(pady=10)

    def buttonPress(self):
        if not self.entry_id_loja.winfo_exists() or not self.entry_nome.winfo_exists():
            print("A janela de cadastro foi fechada.")
            return

        id_loja = self.entry_id_loja.get()
        nome = self.entry_nome.get()
        quantidade = self.entry_quantidade.get()
        tipo = self.entry_tipo.get()
        artesao = self.entry_artesao.get()
        id_joia = self.entry_id.get()

        if not all([id_loja, nome, quantidade, tipo, artesao, id_joia]):
            print("Preencha todos os campos.")
            return

        try:
            quantidade_int = int(quantidade)
            id_loja_int = int(id_loja)
            id_joia_int = int(id_joia)

            self.joia_banco.insert_new_Joia(id_loja_int, nome, quantidade_int, tipo, id_joia_int, artesao)
            self.complete_lista_tipo_Joia()
        except ValueError as e:
            print(f"Erro ao converter valores: {e}")
        except Exception as e:
            print(f"Erro ao cadastrar joia: {e}")

    def complete_lista_tipo_Joia(self):
        lista_Joias_banco_dados = self.joia_banco.get_all_Joia()
        lista_tipo_Joia = sorted([joia.tipo for joia in lista_Joias_banco_dados], reverse=True)
        self.listbox.delete(0, tk.END)
        for nome in lista_tipo_Joia:
            self.listbox.insert(tk.END, nome)

    def atualizar_lista_Joias(self):
        if hasattr(self, 'listbox_Joias'):
            self.listbox_Joias.delete(0, tk.END)
            lista_joias = self.joia_banco.get_all_Joia()
            for joia in lista_joias:
                self.listbox_Joias.insert(tk.END, f"ID: {joia.id_joia} - Nome: {joia.nome} - Tipo: {joia.tipo} - Quantidade: {joia.quantidade}")

    def limpar_campos(self):
        self.entry_id_loja.delete(0, tk.END)
        self.entry_nome.delete(0, tk.END)
        self.entry_quantidade.delete(0, tk.END)
        self.entry_tipo.delete(0, tk.END)
        self.entry_id.delete(0, tk.END)
        self.entry_artesao.delete(0, tk.END)

if __name__ == "__main__":
    root = ctk.CTk()
    try:
        app = TelaHome(root)
    except Exception as e:
        print(f"Erro ao iniciar a aplicação: {e}")
    root.mainloop()
