import psycopg2
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.FuncionarioLojaBanco import FuncionarioLojaBanco
from backend.JoiaBanco import JoiaBanco
from frontend.TelaHome import TelaHome

class LojaBanco:
    def __init__(self):
        self.lojas = []

    def conectar_db(self):
        try:
            return psycopg2.connect(
                dbname='loja de joias',
                user="postgres",
                password="pabdPris",
                host='localhost',
                port=5432
            )
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def cadastrar_loja(self, id_loja, nome_loja, cod_funcionarioloja, joia_id):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Não foi possível cadastrar a loja.")
                return
            try:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO Loja (id, nome, cod_funcionarioLoja, Joia_id) 
                        VALUES (%s, %s, %s, %s);
                    """, (id_loja, nome_loja, cod_funcionarioloja, joia_id))
                    conn.commit()
                    print("Loja cadastrada com sucesso.")
            except Exception as e:
                print(f"Erro ao cadastrar loja: {e}")

    def criar_tabela_Loja(self):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Tabela não criada.")
                return
            
            try:
                with conn.cursor() as cursor:
                    create_Loja_table = '''
                    CREATE TABLE IF NOT EXISTS Loja (
                        id SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        cod_funcionarioLoja INT REFERENCES FuncionarioLoja(cod),
                        Joia_id INT REFERENCES Joia(id)
                    );
                    '''
                    cursor.execute(create_Loja_table)
                    conn.commit()
                    print("Tabela Loja criada com sucesso.")
            except Exception as e:
                print(f"Erro ao criar tabela Loja: {e}")

    def verifica_Joia_existente(self, joia_id):
        with self.conectar_db() as conn:
            if conn is None:
                return False
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT COUNT(*) FROM Joia WHERE id = %s;", (joia_id,))
                    return cursor.fetchone()[0] > 0
            except Exception as e:
                print(f"Erro ao verificar Joia: {e}")
                return False

    def inserir_dados(self, id, nome, cod_funcionario, Joia_id):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Não foi possível inserir dados.")
                return

            try:
                with conn.cursor() as cursor:
                    insert_query = '''
                    INSERT INTO Loja (id, nome, cod_funcionarioLoja, Joia_id)
                    VALUES (%s, %s, %s, %s);
                    '''
                    cursor.execute(insert_query, (id, nome, cod_funcionario, Joia_id))
                    conn.commit()
                    print("Dados inseridos com sucesso.")
            except Exception as e:
                print(f"Erro ao inserir dados na tabela Loja: {e}")

    def atualizar_dados(self, id, novo_nome):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Não foi possível atualizar dados.")
                return
            
            try:
                with conn.cursor() as cursor:
                    cmd_sql = '''
                    UPDATE Loja
                    SET nome = %s WHERE id = %s;
                    '''
                    cursor.execute(cmd_sql, (novo_nome, id))
                    conn.commit()
                    print("Dados atualizados na tabela Loja com sucesso.")
            except Exception as e:
                print(f"Erro ao atualizar dados na tabela Loja: {e}")

    def get_all_Lojas(self):
        with self.conectar_db() as conn:
            if conn is None:
                return []
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT * FROM Loja;")
                    return cursor.fetchall()
            except Exception as e:
                print(f"Erro ao obter Lojas: {e}")
                return []

    def get_funcionarios_da_loja(self, id_loja):
        with self.conectar_db() as conn:
            if conn is None:
                return []
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT * FROM FuncionarioLoja WHERE cod = %s;", (id_loja,))
                    return cursor.fetchall()
            except Exception as e:
                print(f"Erro ao obter funcionários: {e}")
                return []

    def atualizar_funcionario(self, cod_funcionarioloja, novo_nome):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Não foi possível atualizar o funcionário.")
                return
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute("UPDATE FuncionarioLoja SET nome = %s WHERE id = %s", (novo_nome, cod_funcionarioloja))
                    conn.commit()
                    print("Funcionário atualizado com sucesso.")
            except Exception as e:
                print(f"Erro ao atualizar funcionário: {e}")

    def remover_funcionario(self, cod_funcionarioloja):
        with self.conectar_db() as conn:
            if conn is None:
                print("Conexão falhou. Não foi possível remover o funcionário.")
                return
            
            try:
                with conn.cursor() as cursor:
                    cursor.execute("DELETE FROM FuncionarioLoja WHERE id = %s", (cod_funcionarioloja,))
                    conn.commit()
                    print("Funcionário removido com sucesso.")
            except Exception as e:
                print(f"Erro ao remover funcionário: {e}")
