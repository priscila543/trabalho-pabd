class Cliente: 
    def __init__(self, codigo ,nome, username, senha, idade):
        self.nome  = nome
        self.username  = username
        self.idade  = idade
        self.senha  = senha
        self.codigo = codigo

    def __str__(self):
        return f"cod: {self.codigo}\nnome:{self.nome}\n username: {self.username}\n senha: {self.senha}\n idade: {self.idade} "
    
    #essa é minha class usuario (tudo que for sobre usuario é o cliente)