class Cliente:
    def __init__(self, codigo, nome, username, senha, idade):
        """
        Inicializa um objeto Cliente com os dados fornecidos.

        :param codigo: Código único do cliente.
        :param nome: Nome do cliente.
        :param username: Nome de usuário do cliente.
        :param senha: Senha do cliente.
        :param idade: Idade do cliente.
        """
        self.nome = nome  # Armazena o nome do cliente
        self.username = username  # Armazena o nome de usuário do cliente
        self.idade = idade  # Armazena a idade do cliente
        self.senha = senha  # Armazena a senha do cliente
        self.codigo = codigo  # Armazena o código único do cliente

    def __str__(self):
        """
        Retorna uma representação em string do objeto Cliente, formatada.

        :return: Uma string que representa os dados do cliente.
        """
        return (f"cod: {self.codigo}\nnome: {self.nome}\nusername: {self.username}\nsenha: {self.senha}\nidade: {self.idade}")

#essa é minha class usuario (tudo que for sobre usuario é o cliente)