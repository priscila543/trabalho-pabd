class Joia:
    def __init__(self, id_loja, nome, quantidade, tipo, id_joia, artesao):
        """
        Inicializa uma nova instância da classe Joia com os atributos fornecidos.
        
        :param id_loja: ID da loja onde a joia está disponível.
        :param nome: Nome da joia.
        :param quantidade: Quantidade disponível da joia.
        :param tipo: Tipo da joia (por exemplo, colar, pulseira).
        :param id_joia: ID único da joia.
        :param artesao: Nome do artesão que fez a joia.
        """
        self.id_loja = id_loja  # Atributo que armazena o ID da loja
        self.nome = nome  # Atributo que armazena o nome da joia
        self.quantidade = quantidade  # Atributo que armazena a quantidade da joia
        self.tipo = tipo  # Atributo que armazena o tipo da joia
        self.id_joia = id_joia  # Atributo que armazena o ID único da joia
        self.artesao = artesao  # Atributo que armazena o nome do artesão

    def __str__(self):
        """
        Retorna uma representação em string da instância da classe Joia.
        
        :return: Uma string formatada contendo informações sobre a joia.
        """
        return (f"id_loja: {self.id_loja}\nJoia: {self.nome}\nTipo: {self.tipo}\nQuantidade: {self.quantidade}\nID joia: {self.id_joia}\nArtesão: {self.artesao}")
