class Joia:
    def __init__(self, id_loja, nome, quantidade, tipo, id_joia, artesao):
        self.id_loja = id_loja
        self.nome = nome
        self.quantidade = quantidade
        self.tipo = tipo
        self.id_loja = id_joia
        self.artesao = artesao

    def __str__(self):
        return f"id_loja: {self.id_loja}, Joia: {self.nome}, Tipo: {self.tipo}, Quantidade: {self.quantidade}, ID joia: {self.id_joia}, Artesão: {self.artesao}"
    