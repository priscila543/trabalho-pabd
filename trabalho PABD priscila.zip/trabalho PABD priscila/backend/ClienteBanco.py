import psycopg2
from backend.Cliente import Cliente

class ClienteBanco:
    def __init__(self):
        pass

    def get_cliente_pelo_nome(self, nome_digitado):
        cliente = None 
        try:
            conexao = psycopg2.connect(
                dbname='loja de joias',
                user='postgres',
                password='pabdPris',
                host='localhost',
                port='5432'
            )
            cursor = conexao.cursor()  

            query = "SELECT * FROM Cliente WHERE nome = %s"  
            cursor.execute(query, (nome_digitado,))
            result = cursor.fetchone()  

            if result is not None:
                codigo = result[0]
                nome = result[1]
                username = result[2]
                senha = result[3]
                idade = result[4]
                cliente = Cliente(codigo, nome, username, senha, idade)
        
        except Exception as e:
            print(f"Ocorreu um erro: {e}")
            return None
        
        finally:
            if cursor is not None:
                cursor.close()  
            if conexao is not None:
                conexao.close() 

        return cliente 
