import psycopg2
from backend.Cliente import Cliente  # Importa a classe Cliente do módulo backend

class ClienteBanco:
    def __init__(self):
        """
        Inicializa a classe ClienteBanco. Neste caso, o construtor não faz nada.
        """
        pass

    def get_cliente_pelo_nome(self, nome_digitado):
        """
        Busca um cliente no banco de dados pelo nome fornecido.

        :param nome_digitado: O nome do cliente a ser buscado.
        :return: Um objeto Cliente se encontrado, ou None se não encontrado ou ocorrer um erro.
        """
        cliente = None  # Inicializa a variável cliente como None
        try:
            # Estabelece uma conexão com o banco de dados PostgreSQL
            conexao = psycopg2.connect(
                dbname='loja de joias',
                user='postgres',
                password='pabdPris',
                host='localhost',
                port='5432'
            )
            cursor = conexao.cursor()  # Cria um cursor para executar comandos SQL

            # Define a consulta SQL para buscar o cliente pelo nome
            query = "SELECT * FROM Cliente WHERE nome = %s"
            cursor.execute(query, (nome_digitado,))  # Executa a consulta passando o nome

            result = cursor.fetchone()  # Obtém o resultado da consulta

            if result is not None:
                # Se um resultado foi encontrado, extrai os dados e cria um objeto Cliente
                codigo = result[0]
                nome = result[1]
                username = result[2]
                senha = result[3]
                idade = result[4]
                cliente = Cliente(codigo, nome, username, senha, idade)  # Cria o objeto Cliente

        except Exception as e:
            print(f"Ocorreu um erro: {e}")  # Exibe um erro caso ocorra
            return None  # Retorna None em caso de erro
        
        finally:
            # Garante que o cursor e a conexão sejam fechados, se foram abertos
            if cursor is not None:
                cursor.close()  
            if conexao is not None:
                conexao.close() 

        return cliente  # Retorna o objeto Cliente encontrado ou None
