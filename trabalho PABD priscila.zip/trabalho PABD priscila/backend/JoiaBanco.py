import psycopg2  # Importa a biblioteca psycopg2 para interagir com o banco de dados PostgreSQL
import sys
import os

# Adiciona o diretório pai ao caminho do sistema para permitir a importação de módulos
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from backend.Joia import Joia  # Importa a classe Joia de outro módulo

class Joia:
    def __init__(self, id_loja, nome, quantidade, tipo, id_joia, artesao):
        """Inicializa uma instância da classe Joia com os atributos fornecidos."""
        self.id_loja = id_loja  # ID da loja onde a joia está
        self.nome = nome  # Nome da joia
        self.quantidade = quantidade  # Quantidade da joia disponível
        self.tipo = tipo  # Tipo da joia
        self.id_joia = id_joia  # ID único da joia
        self.artesao = artesao  # Nome do artesão que fez a joia

    def get_tipo(self):
        """Retorna o tipo da joia."""
        return self.tipo
    
class JoiaBanco:
    def __init__(self):
        """Inicializa a classe JoiaBanco e estabelece a conexão com o banco de dados."""
        self.joias = []  # Lista para armazenar as joias
        self.conexao = self.conectar_db()  # Conecta ao banco de dados
        self.cursor = self.conexao.cursor()  # Cria um cursor para executar comandos SQL
        self.criar_tabela_Joia()  # Cria a tabela Joia se não existir
    
    @staticmethod
    def conectar_db():
        """Estabelece a conexão com o banco de dados PostgreSQL."""
        try:
            return psycopg2.connect(
                dbname='loja de joias',  # Nome do banco de dados
                user='postgres',  # Nome de usuário do banco de dados
                password='pabdPris',  # Senha do banco de dados
                host='localhost',  # Host do banco de dados
                port=5432,  # Porta do banco de dados
                options='-c client_encoding=UTF8'  # Define a codificação do cliente para UTF-8
            )
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")  # Exibe mensagem de erro se a conexão falhar
            return None
    
    def criar_tabela_Joia(self):
        """Cria a tabela Joia no banco de dados se não existir."""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS joia (
                id INTEGER PRIMARY KEY,  
                nome TEXT NOT NULL,  
                quantidade INTEGER NOT NULL,  
                tipo TEXT NOT NULL,  
                id_joia INTEGER NOT NULL,  
                artesao TEXT NOT NULL  
            );
        ''')
        self.conexao.commit()  # Confirma a criação da tabela

    def insert_new_Joia(self, id_loja, nome, quantidade, tipo, id_joia, artesao):
        """Adiciona uma nova joia à lista de joias."""
        nova_joia = Joia(id_loja, nome, quantidade, tipo, id_joia, artesao)  # Cria uma nova instância da classe Joia
        self.joias.append(nova_joia)  # Adiciona a nova joia à lista
        print(f"Joia '{nome}' adicionada com sucesso!")  # Mensagem de sucesso

    def get_all_Joia(self):
        """Retorna todas as joias armazenadas."""
        return self.joias  # Retorna a lista de joias

    def update_Joia(self, id_joia, novo_nome=None, nova_quantidade=None, novo_tipo=None, novo_artesao=None):
        """Atualiza os atributos de uma joia existente com base no ID da joia."""
        for joia in self.joias:
            if joia.id_joia == id_joia:  # Verifica se a joia com o ID fornecido existe
                if novo_nome is not None:
                    joia.nome = novo_nome  # Atualiza o nome se um novo valor for fornecido
                if nova_quantidade is not None:
                    joia.quantidade = nova_quantidade  # Atualiza a quantidade
                if novo_tipo is not None:
                    joia.tipo = novo_tipo  # Atualiza o tipo
                if novo_artesao is not None:
                    joia.artesao = novo_artesao  # Atualiza o artesão
                print(f"Joia com ID '{id_joia}' atualizada com sucesso!")  # Mensagem de sucesso
                return
        print(f"Joia com ID '{id_joia}' não encontrada.")  # Mensagem se a joia não for encontrada

    def remover_Joia(self, id_joia):
        """Remove uma joia da lista com base no ID da joia."""
        self.joias = [joia for joia in self.joias if joia.id_joia != id_joia]  # Filtra a lista para remover a joia com o ID fornecido

if __name__ == "__main__":
    # Código de exemplo para testar a classe JoiaBanco
    joia_banco = JoiaBanco()  # Cria uma nova instância da classe JoiaBanco
    joia_banco.insert_new_Joia("Colar de Pérolas", 10, "Colar", "C001", "Artista A")  # Insere uma nova joia
    joia_banco.insert_new_Joia("Pulseira de Ouro", 5, "Pulseira", "P001", "Artista B")  # Insere outra nova joia
    
    print("Todas as joias:")  # Mensagem antes de listar as joias
    for joia in joia_banco.get_all_Joia():  # Obtém todas as joias
        print(f"Nome: {joia.nome}, Tipo: {joia.tipo}, ID: {joia.id_joia}, Artesão: {joia.artesao}, Quantidade: {joia.quantidade}")
    
    joia_banco.update_Joia("C001", novo_nome="Colar de Cristal", nova_quantidade=15)  # Atualiza uma joia existente

    joia_banco.remover_Joia("P001")  # Remove uma joia existente
    
    print("Joias após atualização e remoção:")  # Mensagem antes de listar as joias novamente
    for joia in joia_banco.get_all_Joia():  # Obtém todas as joias
        print(f"Nome: {joia.nome}, Tipo: {joia.tipo}, ID: {joia.id_joia}, Artesão: {joia.artesao}, Quantidade: {joia.quantidade}")
