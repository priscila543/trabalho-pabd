class FuncionarioLoja:
    def __init__(self, cod, nome, username, senha):
        """
        Inicializa uma instância da classe FuncionarioLoja com os atributos fornecidos.

        :param cod: Código do funcionário (identificador único).
        :param nome: Nome do funcionário.
        :param username: Nome de usuário do funcionário.
        :param senha: Senha do funcionário.
        """
        self.cod = cod          # Atribui o código do funcionário
        self.username = username  # Atribui o nome de usuário
        self.nome = nome        # Atribui o nome completo
        self.senha = senha      # Atribui a senha

    def __str__(self):
        """
        Retorna uma representação em string da instância FuncionarioLoja.
        
        :return: String formatada com os detalhes do funcionário.
        """
        return f"codigo: {self.cod}\nnome: {self.nome}\nusername: {self.username}\nsenha: {self.senha}\n"

        