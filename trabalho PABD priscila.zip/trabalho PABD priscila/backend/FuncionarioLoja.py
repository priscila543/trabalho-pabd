class FuncionarioLoja:

    def __init__(self, cod, nome, username, senha ):
        self.cod = cod
        self.username = username
        self.nome = nome
        self.senha = senha
        
    def __str__(self):
        return f"codigo: {self.cod}\nnome:{self.nome}\nusername: {self.username}senha: {self.senha}\n "
        