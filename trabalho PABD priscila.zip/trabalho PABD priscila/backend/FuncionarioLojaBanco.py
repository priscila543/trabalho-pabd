import psycopg2  # Importa a biblioteca para interação com o banco de dados PostgreSQL
import sys
import os

# Adiciona o caminho do diretório pai ao sistema de módulos
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

# Importa a classe FuncionarioLoja do módulo backend
from backend.FuncionarioLoja import FuncionarioLoja

class FuncionarioLojaBanco:
    def __init__(self):
        """
        Inicializa a classe FuncionarioLojaBanco, estabelecendo a conexão com o banco de dados.
        """
        self.conn = self.conectar_db()  # Chama o método para conectar ao banco de dados
    
    def conectar_db(self):
        """
        Estabelece a conexão com o banco de dados PostgreSQL.
        
        :return: Conexão com o banco de dados ou None em caso de erro.
        """
        try:
            conn = psycopg2.connect(
                dbname='loja de joias',  # Nome do banco de dados
                user='postgres',  # Usuário do banco de dados
                password='pabdPris',  # Senha do usuário
                host='localhost',  # Endereço do servidor
                port=5432,  # Porta do banco de dados
                options='-c client_encoding=UTF8'  # Define a codificação do cliente
            )
            return conn
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def criar_tabela_FuncionarioLoja(self):
        create_FuncionarioLoja_table = '''
        CREATE TABLE IF NOT EXISTS FuncionarioLoja (
            cod int PRIMARY KEY,
            nome VARCHAR(50) NOT NULL,
            username VARCHAR(50),
            senha VARCHAR(60)
        ); '''
        
        with self.conn:  # Garante que a conexão será fechada após o bloco
            with self.conn.cursor() as db_cursor:  # Cria um cursor para executar comandos SQL
                try:
                    db_cursor.execute(create_FuncionarioLoja_table)  # Executa o comando de criação da tabela
                    print("Tabela FuncionarioLoja criada com sucesso.")
                    
                    # Insere dados iniciais na tabela
                    self.inserir_dados(12345, 'pri', 'primiranda', '123456789')
                    self.inserir_dados(54321, 'naza', 'nazare', '12345')
                except Exception as e:
                    print(f"Erro ao criar tabela ou inserir dados: {e}")

    def inserir_dados(self, cod, nome, username, senha):
        cmd_sql = '''
        INSERT INTO FuncionarioLoja (cod, nome, username, senha) VALUES (%s, %s, %s, %s);
        '''
        
        with self.conn:  # Garante que a conexão será fechada após o bloco
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (cod, nome, username, senha))  # Executa o comando de inserção
                    print("FuncionárioLoja adicionado com sucesso.")
                except Exception as e:
                    print(f"Erro ao adicionar funcionárioLoja: {e}")

    def atualizar_dados(self, novo_nome, novo_username, nova_senha, cod):
        cmd_sql = '''
        UPDATE FuncionarioLoja
        SET nome = %s, username = %s, senha = %s
        WHERE cod = %s;
        '''
        
        with self.conn:  # Garante que a conexão será fechada após o bloco
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (novo_nome, novo_username, nova_senha, cod))  # Executa o comando de atualização
                    print("Dados atualizados na tabela FuncionarioLoja com sucesso.")
                except Exception as e:
                    print(f"Erro ao atualizar dados: {e}")

    def remover_FuncionarioLoja(self, cod):
        cmd_sql = '''
        DELETE FROM FuncionarioLoja WHERE cod = %s;
        '''
        
        with self.conn:  # Garante que a conexão será fechada após o bloco
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (cod,))  # Executa o comando de remoção
                    print("FuncionárioLoja removido com sucesso.")
                except Exception as e:
                    print(f"Erro ao remover funcionárioLoja: {e}")

    def get_FuncionarioLoja_by_username(self, username):
        """
        Busca um funcionário pelo nome de usuário.
        
        :param username: Nome de usuário do funcionário a ser buscado.
        :return: Instância de FuncionarioLoja ou None se não encontrado.
        """
        if not self.conn:  # Verifica se a conexão está estabelecida
            print("Conexão não estabelecida.")
            return None

        with self.conn.cursor() as cursor:  # Cria um cursor para executar comandos SQL
            try:
                cursor.execute("SELECT * FROM FuncionarioLoja WHERE username = %s;", (username,))  # Executa a busca
                result = cursor.fetchone()  # Obtém o primeiro resultado
                if result:
                    return FuncionarioLoja(*result)  # Retorna uma instância de FuncionarioLoja
                return None
            except Exception as e:
                print(f"Erro ao consultar o funcionário: {e}")
                return None
        
    def get_all_FuncionariosLoja(self):
        """
        Obtém todos os funcionários cadastrados na tabela FuncionarioLoja.
        
        :return: Lista de todos os funcionários.
        """
        FuncionariosLoja = []
        with self.conn:  # Garante que a conexão será fechada após o bloco
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute("SELECT * FROM FuncionarioLoja;")  # Executa a consulta para obter todos os funcionários
                    FuncionariosLoja = db_cursor.fetchall()  # Armazena todos os resultados
                except Exception as e:
                    print(f"Erro ao obter funcionáriosLoja: {e}")
        
        return FuncionariosLoja  # Retorna a lista de funcionários
