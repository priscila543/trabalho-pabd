import psycopg2
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from backend.FuncionarioLoja import FuncionarioLoja

class FuncionarioLojaBanco:
    def __init__(self):
        self.conn = self.conectar_db()
    
    def conectar_db(self):
        try:
            conn = psycopg2.connect(
                dbname='loja de joias',
                user='postgres',
                password='pabdPris',
                host='localhost',
                port=5432,
                options='-c client_encoding=UTF8'
            )
            return conn
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def criar_tabela_FuncionarioLoja(self):
        create_FuncionarioLoja_table = '''
        CREATE TABLE IF NOT EXISTS FuncionarioLoja (
            cod int PRIMARY KEY,
            nome VARCHAR(50) NOT NULL,
            username VARCHAR(50),
            senha VARCHAR(60)
        ); '''
        
        with self.conn:
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(create_FuncionarioLoja_table)  
                    print("Tabela FuncionarioLoja criada com sucesso.")
                    
                    self.inserir_dados(12345, 'pri', 'primiranda', '123456789')
                    self.inserir_dados(54321, 'naza', 'nazare', '12345')
                except Exception as e:
                    print(f"Erro ao criar tabela ou inserir dados: {e}")

    def inserir_dados(self, cod, nome, username, senha):
        cmd_sql = '''
        INSERT INTO FuncionarioLoja (cod, nome, username, senha) VALUES (%s, %s, %s, %s);
        '''
        
        with self.conn:
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (cod, nome, username, senha))
                    print("FuncionárioLoja adicionado com sucesso.")
                except Exception as e:
                    print(f"Erro ao adicionar funcionárioLoja: {e}")

    def atualizar_dados(self, novo_nome, novo_username, nova_senha, cod):
        cmd_sql = '''
        UPDATE FuncionarioLoja
        SET nome = %s, username = %s, senha = %s
        WHERE cod = %s;
        '''
        
        with self.conn:
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (novo_nome, novo_username, nova_senha, cod))
                    print("Dados atualizados na tabela FuncionarioLoja com sucesso.")
                except Exception as e:
                    print(f"Erro ao atualizar dados: {e}")

    def remover_FuncionarioLoja(self, cod):
        cmd_sql = '''
        DELETE FROM FuncionarioLoja WHERE cod = %s;
        '''
        
        with self.conn:
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute(cmd_sql, (cod,))
                    print("FuncionárioLoja removido com sucesso.")
                except Exception as e:
                    print(f"Erro ao remover funcionárioLoja: {e}")

    def get_FuncionarioLoja_by_username(self, username):
        if not self.conn:
            print("Conexão não estabelecida.")
            return None

        with self.conn.cursor() as cursor:
            try:
                cursor.execute("SELECT * FROM FuncionarioLoja WHERE username = %s;", (username,))
                result = cursor.fetchone()
                if result:
                    return FuncionarioLoja(*result)  
                return None
            except Exception as e:
                print(f"Erro ao consultar o funcionário: {e}")
                return None
        
    def get_all_FuncionariosLoja(self):
        FuncionariosLoja = []
        with self.conn:
            with self.conn.cursor() as db_cursor:
                try:
                    db_cursor.execute("SELECT * FROM FuncionarioLoja;")
                    FuncionariosLoja = db_cursor.fetchall()  
                except Exception as e:
                    print(f"Erro ao obter funcionáriosLoja: {e}")
        
        return FuncionariosLoja
