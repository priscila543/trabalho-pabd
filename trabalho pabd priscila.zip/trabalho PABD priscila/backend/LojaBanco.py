import psycopg2
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.FuncionarioLojaBanco import FuncionarioLojaBanco
from backend.JoiaBanco import JoiaBanco
from frontend.TelaHome import TelaHome

class LojaBanco:
    def __init__(self):
        self.lojas = []  

    def conectar_db(self):
        try:
            return psycopg2.connect(
                dbname='loja de joias',
                user="postgres",
                password="pabdPris",
                host='localhost',
                port=5432
            )
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def criar_tabela_Loja(self):
        conn = self.conectar_db()
        if conn is None:
            print("Conexão falhou. Tabela não criada.")
            return
        
        try:
            with conn.cursor() as cursor:
                create_Loja_table = '''
                CREATE TABLE IF NOT EXISTS Loja (
                    id SERIAL PRIMARY KEY,
                    nome VARCHAR(100) NOT NULL,
                    crm_funcionarioLoja INT REFERENCES FuncionarioLoja(CRM),
                    codigo_Joia INT REFERENCES Joia(cod)
                );
                '''
                cursor.execute(create_Loja_table)
                conn.commit()
                print("Tabela Loja criada com sucesso.")
        except Exception as e:
            print(f"Erro ao criar tabela Loja: {e}")
        finally:
            conn.close()

    def verifica_Loja_existente(self, nome, crm_funcionario, cod_joia):
        lojas = self.get_all_Lojas()
        for loja in lojas:
            if loja[1] == nome and loja[2] == crm_funcionario and loja[3] == cod_joia:
                return True
        return False

    def inserir_dados(self, id, nome, crm_funcionario, cod_joia):
        conn = self.conectar_db()
        if conn is None:
            print("Conexão falhou. Não foi possível inserir dados.")
            return

        try:
            with conn:
                with conn.cursor() as cursor:
                    insert_query = '''
                    INSERT INTO Loja (id, nome, crm_funcionarioLoja, codigo_Joia)
                    VALUES (%s, %s, %s, %s);
                    '''
                    cursor.execute(insert_query, (id, nome, crm_funcionario, cod_joia))
                    print("Dados inseridos com sucesso.")
        except Exception as e:
            print(f"Erro ao inserir dados na tabela Loja: {e}")
        finally:
            conn.close()

    def atualizar_dados(self, id, novo_nome):
        conn = self.conectar_db()
        if conn is None:
            return
        
        try:
            with conn.cursor() as cursor:
                cmd_sql = '''
                UPDATE Loja
                SET nome = %s WHERE id = %s;
                '''
                cursor.execute(cmd_sql, (novo_nome, id))
                conn.commit()
                print("Dados atualizados na tabela Loja com sucesso.")
        except Exception as e:
            print(f"Erro ao atualizar dados na tabela Loja: {e}")
        finally:
            conn.close()

    def get_all_Lojas(self):
        conn = self.conectar_db()
        if conn is None:
            return []
        
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM Loja;")
                return cursor.fetchall()
        except Exception as e:
            print(f"Erro ao obter Lojas: {e}")
            return []
        finally:
            conn.close()

   
    

