import psycopg2
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from backend.Joia import Joia

class Joia:
    def __init__(self, id_loja, nome, quantidade, tipo, codigo, artesao):
        id_loja = id_loja
        self.nome = nome
        self.quantidade = quantidade
        self.tipo = tipo
        self.codigo = codigo
        self.artesao = artesao

    def get_tipo(self):
        return self.tipo
    
class JoiaBanco:
    def __init__(self):
        self.joias = []
        self.conexao = self.conectar_db()
        self.cursor = self.conexao.cursor()
        self.criar_tabela_Joia()
    
    @staticmethod
    def conectar_db():
        try:
            return psycopg2.connect(
                dbname='loja de joias',
                user='postgres',
                password='pabdPris',
                host='localhost',
                port=5432,
                options='-c client_encoding=UTF8'
            )
        except Exception as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None
    
    def criar_tabela_Joia(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS joias (
                id INTEGER PRIMARY KEY,
                nome TEXT NOT NULL,
                quantidade INTEGER NOT NULL,
                tipo TEXT NOT NULL,
                codigo INTEGER NOT NULL,
                artesao TEXT NOT NULL
            )
        ''')
        self.conexao.commit()

    def insert_new_Joia(self, nome, quantidade, tipo, codigo, artesao):
        nova_joia = Joia(nome, quantidade, tipo, codigo, artesao)
        self.joias.append(nova_joia)
        print(f"Joia '{nome}' adicionada com sucesso!")

    def get_all_Joia(self):
        return self.joias

    def update_Joia(self, codigo, novo_nome=None, nova_quantidade=None, novo_tipo=None, novo_artesao=None):
        for joia in self.joias:
            if joia.codigo == codigo:
                if novo_nome is not None:
                    joia.nome = novo_nome
                if nova_quantidade is not None:
                    joia.quantidade = nova_quantidade
                if novo_tipo is not None:
                    joia.tipo = novo_tipo
                if novo_artesao is not None:
                    joia.artesao = novo_artesao
                print(f"Joia com código '{codigo}' atualizada com sucesso!")
                return
        print(f"Joia com código '{codigo}' não encontrada.")

    def remove_Joia(self, codigo):
        for joia in self.joias:
            if joia.codigo == codigo:
                self.joias.remove(joia)
                print(f"Joia com código '{codigo}' removida com sucesso!")
                return
        print(f"Joia com código '{codigo}' não encontrada.")

if __name__ == "__main__":
    joia_banco = JoiaBanco()
    joia_banco.insert_new_Joia("Colar de Pérolas", 10, "Colar", "C001", "Artista A")
    joia_banco.insert_new_Joia("Pulseira de Ouro", 5, "Pulseira", "P001", "Artista B")
    
    print("Todas as joias:")
    for joia in joia_banco.get_all_Joia():
        print(f"Nome: {joia.nome}, Tipo: {joia.tipo}, Código: {joia.codigo}, Artesão: {joia.artesao}, Quantidade: {joia.quantidade}")
    
    joia_banco.update_Joia("C001", novo_nome="Colar de Cristal", nova_quantidade=15)

    joia_banco.remove_Joia("P001")
    
    print("Joias após atualização e remoção:")
    for joia in joia_banco.get_all_Joia():
        print(f"Nome: {joia.nome}, Tipo: {joia.tipo}, Código: {joia.codigo}, Artesão: {joia.artesao}, Quantidade: {joia.quantidade}")
