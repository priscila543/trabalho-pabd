class Cliente: 
    def __init__(self, cod ,nome, username, senha, idade):
        self.nome  = nome
        self.username  = username
        self.idade  = idade
        self.senha  = senha
        self.cod = cod

    def __st_r_(self):
        return f"cod: {self.cod}\nnome:{self.nome}\n username: {self.username}\n senha: {self.senha}\n idade: {self.idade} "
    
    #essa é minha class usuario (tudo que for sobre usuario é o cliente)