class FuncionarioLoja:

    def __init__(self, CRM, nome, username, senha ):
        self.CRM = CRM
        self.username = username
        self.nome = nome
        self.senha = senha
        
    def _str_(self):
        return f"CRM: {self.CRM}\nnome:{self.nome}\nusername: {self.username}senha: {self.senha}\n "
        