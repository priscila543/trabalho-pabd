from backend.ClienteBanco import ClienteBanco

from backend.Cliente import Cliente

from frontend.TelaFuncionarioLoja import TelaFuncionarioLoja

from frontend.TelaJoia import TelaJoia

from frontend.TelaLogin import TelaLogin

from frontend.TelaHome import TelaHome

from frontend.TelaLoja import TelaLoja