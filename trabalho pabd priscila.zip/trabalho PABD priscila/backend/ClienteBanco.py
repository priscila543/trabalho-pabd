import psycopg2
from backend.Cliente import Cliente

class ClienteBanco:
    def __init__(self):
        pass

    def get_cliente_pelo_nome(self, nome):
        try:
            conexao = psycopg2.connect(
                dbname='loja de joias',
                user='postgres',
                password='pabdPris',
                host='localhost',
                port='5432'
            )
            cursor = conexao.cursor()

            cod_sql = "SELECT * FROM Cliente WHERE nome = %s;"
            cursor.execute(cod_sql, (nome,))

            result = cursor.fetchone()
        
        except Exception as e:
            print(f"Erro ao buscar cliente: {e}")
            return None
        
        finally:
            cursor.close()
            conexao.close()

        if result is not None:
            cod = result[0]
            nome = result[1]
            username = result[2]
            senha = result[3]
            idade = result[4]
            cliente = Cliente(cod, nome, username, senha, idade)
        else:
            cliente = None

        return cliente
