class Joia:

    def __init__(self, id_loja, nome, quantidade, tipo, codigo, artesao):
        self.id_loja = id_loja
        self.nome = nome
        self.tipo = tipo
        self.quantidade = quantidade
        self.codigo = codigo
        self.artesao = artesao

    def __str__(self):
        return f"Joia: {self.nome}, Tipo: {self.tipo}, Quantidade: {self.quantidade}, Código: {self.codigo}, Artesão: {self.artesao}"
    