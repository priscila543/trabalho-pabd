import psycopg2
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from backend.FuncionarioLoja import FuncionarioLoja

class FuncionarioLojaBanco:
    def __init__(self):
        pass
    
    def conectar_db(self):
        return psycopg2.connect(
            dbname='loja de joias',
            user='postgres',
            password='pabdPris',
            host='localhost',
            port=5432
        )

    def criar_tabela_FuncionarioLoja(self):
        db_connection = self.conectar_db()
        db_cursor = db_connection.cursor()
        
        create_FuncionarioLoja_table = '''
        CREATE TABLE IF NOT EXISTS FuncionarioLoja (
            CRM int PRIMARY KEY,
            nome VARCHAR(50) NOT NULL,
            username VARCHAR(50),
            senha VARCHAR(60)
        ); '''
        
        try:
            db_cursor.execute(create_FuncionarioLoja_table)  
            db_connection.commit()

            self.inserir_dados(12345, 'pri', 'primiranda', '123456789')
            self.inserir_dados(54321, 'naza', 'nazare', '12345')

            print("Tabela FuncionarioLoja criada e dados inseridos com sucesso.")
        except Exception as e:
            print(f"Erro ao criar tabela ou inserir dados: {e}")
        finally:
            db_cursor.close()
            db_connection.close()
    
    def inserir_dados(self, crm, nome, username, senha):
        db_connection = self.conectar_db()
        db_cursor = db_connection.cursor()
        
        cmd_sql = '''
        INSERT INTO FuncionarioLoja (CRM, nome, username, senha) VALUES (%s, %s, %s, %s);
        '''
        
        try:
            db_cursor.execute(cmd_sql, (crm, nome, username, senha))
            db_connection.commit()
            print("FuncionárioLoja adicionado com sucesso.")
        except Exception as e:
            print(f"Erro ao adicionar funcionárioLoja: {e}")
        finally:
            db_cursor.close()
            db_connection.close()

    def atualizar_dados(self, novo_nome, novo_username, nova_senha, crm):
        db_connection = self.conectar_db()
        db_cursor = db_connection.cursor()
        
        cmd_sql = '''
        UPDATE FuncionarioLoja
        SET nome = %s, username = %s, senha = %s
        WHERE CRM = %s;
        '''
        
        db_cursor.execute(cmd_sql, (novo_nome, novo_username, nova_senha, crm))
        db_connection.commit()
        db_cursor.close()
        db_connection.close()
        print("Dados atualizados na tabela FuncionarioLoja com sucesso.")

    def remover_FuncionarioLoja(self, crm):
        db_connection = self.conectar_db()
        db_cursor = db_connection.cursor()
        
        cmd_sql = '''
        DELETE FROM FuncionarioLoja WHERE CRM = %s;
        '''
        
        try:
            db_cursor.execute(cmd_sql, (crm,))
            db_connection.commit()
            print("FuncionárioLoja removido com sucesso.")
        except Exception as e:
            print(f"Erro ao remover funcionárioLOja: {e}")
        finally:
            db_cursor.close()
            db_connection.close()

    def get_FuncionarioLoja_by_username(self, username_farm):
        db_connection = None
        db_cursor = None
        func = None
        
        try:    
            db_connection = self.conectar_db()
            db_cursor = db_connection.cursor()
            cmd_sql = "SELECT * FROM FuncionarioLoja WHERE username = %s;"
            db_cursor.execute(cmd_sql, (username_farm,))
            lista_exibir = db_cursor.fetchone()
            
            if lista_exibir is not None:
                nome_FuncionarioLoja = lista_exibir[1]
                username_FuncionarioLoja = lista_exibir[2]
                id_FuncionarioLoja = lista_exibir[0]
                senha_FuncionarioLoja = lista_exibir[3]
                func = FuncionarioLoja(nome_FuncionarioLoja, username_FuncionarioLoja, id_FuncionarioLoja, senha_FuncionarioLoja)
                print(lista_exibir)
            else:
                func = None

        except Exception as e:
            print(f"Erro ao consultar o funcionárioLoja: {e}")
        finally:
            db_cursor.close()
            db_connection.close()
            return func
        
    def get_all_FuncionariosLoja(self):
        db_connection = self.conectar_db()
        db_cursor = db_connection.cursor()
        FuncionariosLoja = []

        try:
            db_cursor.execute("SELECT * FROM FuncionarioLoja;")
            FuncionariosLoja = db_cursor.fetchall()  
        except Exception as e:
            print(f"Erro ao obter funcionáriosLoja: {e}")
        finally:
            db_cursor.close()
            db_connection.close()
        
        return FuncionariosLoja