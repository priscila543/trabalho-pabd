import tkinter as tk
from tkinter import messagebox
import sys
import os
import customtkinter

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.ClienteBanco import ClienteBanco
from frontend.TelaLoja import TelaLoja

customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("dark-blue")

clienteBanco = ClienteBanco()

def verificar_login():
    nome_digitado = nome.get()
    senha_digitada = senha.get()
    
    cliente = clienteBanco.get_cliente_pelo_nome(nome_digitado)

    if cliente is not None and cliente.senha == senha_digitada:
        messagebox.showinfo("Login", "Login bem-sucedido!")
        abrindo_tela_Loja()
    else: 
        messagebox.showerror("Login", "Nome do cliente ou senha incorretos.")

def abrindo_tela_Loja():
    print("Abrindo TelaLoja")
    janela.withdraw()  
    new_window = tk.Toplevel(janela)  
    from frontend.TelaLoja import TelaLoja  
    TelaLoja(new_window)
    new_window.protocol("WM_DELETE_WINDOW", lambda: voltar(janela))

def voltar(master):
    master.deiconify()  

janela = customtkinter.CTk() 
janela.geometry("590x300")
janela.title("Tela de Login")

texto = customtkinter.CTkLabel(janela, text="Fazer Login") 
texto.pack(padx=10, pady=10)

nome = customtkinter.CTkEntry(janela, placeholder_text="Seu nome") 
nome.pack(padx=10, pady=10)

senha = customtkinter.CTkEntry(janela, placeholder_text="Sua senha", show="*")
senha.pack(padx=10, pady=10)

botao = customtkinter.CTkButton(janela, text="Login", command=verificar_login)
botao.pack(padx=10, pady=10)

janela.mainloop()
