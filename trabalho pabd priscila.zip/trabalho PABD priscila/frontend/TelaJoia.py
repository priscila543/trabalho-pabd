import tkinter as tk
import sys
import os
import psycopg2
import customtkinter as ctk

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.JoiaBanco import JoiaBanco  
from frontend.TelaLoja import TelaLoja

ctk.set_appearance_mode("dark") 
ctk.set_default_color_theme("dark-blue")

class TelaJoia:
    def __init__(self, master, tela_Loja):
        self.master = master
        self.tela_Loja = tela_Loja

        self.Joia_banco = JoiaBanco()  
        self.conexao = self.Joia_banco.conectar_db()
        if self.conexao is None:
            raise Exception("Falha ao conectar ao banco de dados.")
        self.cursor = self.conexao.cursor()  
        self.Joia_banco.criar_tabela_Joia()  
        self.joias = []  

        self.setup_widgets()  

    def setup_widgets(self):
        self.label_titulo = ctk.CTkLabel(self.master, text="Bem-vindo à Loja de Joias")
        self.label_titulo.pack(pady=20)
        
        self.label_nome = ctk.CTkLabel(self.master, text="Nome da joia:")
        self.label_nome.grid(row=0, column=0, pady=5)
        self.entry_nome = ctk.CTkEntry(self.master)
        self.entry_nome.grid(row=0, column=1, pady=5)

        self.label_tipo = ctk.CTkLabel(self.master, text="Tipo da joia:")
        self.label_tipo.grid(row=1, column=0, pady=5)
        self.entry_tipo = ctk.CTkEntry(self.master)
        self.entry_tipo.grid(row=1, column=1, pady=5)

        self.label_quantidade = ctk.CTkLabel(self.master, text="Quantidade:")
        self.label_quantidade.grid(row=2, column=0, pady=5)
        self.entry_quantidade = ctk.CTkEntry(self.master)
        self.entry_quantidade.grid(row=2, column=1, pady=5)

        self.label_codigo = ctk.CTkLabel(self.master, text="Código da joia:")
        self.label_codigo.grid(row=3, column=0, pady=5)
        self.entry_codigo = ctk.CTkEntry(self.master)
        self.entry_codigo.grid(row=3, column=1, pady=5)

        self.label_artesao = ctk.CTkLabel(self.master, text="Artesão:")
        self.label_artesao.grid(row=4, column=0, pady=5)
        self.entry_artesao = ctk.CTkEntry(self.master)
        self.entry_artesao.grid(row=4, column=1, pady=5)

        self.button_adicionar = ctk.CTkButton(self.master, text="Adicionar joia", command=self.adicionar_Joia)
        self.button_adicionar.grid(row=5, columnspan=2, pady=10)

        self.button_atualizar = ctk.CTkButton(self.master, text="Atualizar joia", command=self.atualizar_Joia)
        self.button_atualizar.grid(row=6, columnspan=2, pady=10)

        self.button_remover = ctk.CTkButton(self.master, text="Remover joia", command=self.remover_Joia)
        self.button_remover.grid(row=7, columnspan=2, pady=10)

        self.button_finalizar = ctk.CTkButton(self.master, text="Finalizar sessão", command=self.finalizar_sessao)
        self.button_finalizar.grid(row=8, columnspan=2, pady=10)

        self.listbox_Joias = tk.Listbox(self.master)  
        self.listbox_Joias.grid(row=9, columnspan=2, pady=5)

        self.button_voltar = ctk.CTkButton(self.master, text="Voltar", command=self.voltar)
        self.button_voltar.grid(row=10, columnspan=2, pady=5)

    def adicionar_Joia(self):
        nome = self.entry_nome.get()
        tipo = self.entry_tipo.get()
        artesao = self.entry_artesao.get()
        quantidade = self.entry_quantidade.get()
        codigo = self.entry_codigo.get()

        if nome and tipo and artesao and quantidade.isdigit() and codigo.isdigit():
            self.Joia_banco.insert_new_Joia(nome, int(quantidade), tipo, int(codigo), artesao)
            self.atualizar_lista_Joias()
            self.limpar_campos()
        else:
            print("Preencha todos os campos corretamente.")

    def atualizar_Joia(self):
        selected_index = self.listbox_Joias.curselection()
        if selected_index:
            codigo = int(self.listbox_Joias.get(selected_index).split(",")[0].split(":")[1].strip())
            novo_nome = self.entry_nome.get()
            novo_tipo = self.entry_tipo.get()
            novo_artesao = self.entry_artesao.get()
            nova_quantidade = self.entry_quantidade.get()

            if novo_nome and novo_tipo and nova_quantidade.isdigit() and novo_artesao:
                self.Joia_banco.atualizar_dados(codigo, novo_nome, int(nova_quantidade), novo_tipo, novo_artesao)
                self.atualizar_lista_Joias()
                self.limpar_campos()
            else:
                print("Preencha todos os campos corretamente.")
        else:
            print("Selecione uma joia para atualizar.")

    def remover_Joia(self):
        selected_index = self.listbox_Joias.curselection()
        if selected_index:
            codigo = int(self.listbox_Joias.get(selected_index).split(",")[0].split(":")[1].strip())
            self.Joia_banco.remover_Joia(codigo) 
            self.atualizar_lista_Joias()
            self.limpar_campos()
        else:
            print("Selecione uma joia para remover.")

    def finalizar_sessao(self):
        print("Sessão finalizada") 
        self.master.destroy() 

    def atualizar_lista_Joias(self):
        self.listbox_Joias.delete(0, tk.END)
        for joia in self.Joia_banco.get_all_Joia():
            self.listbox_Joias.insert(tk.END, f"Código: {joia[4]}, Nome: {joia[1]}, Tipo: {joia[3]}, Qtd: {joia[2]}, Artesão: {joia[5]}")

    def limpar_campos(self):
        self.entry_nome.delete(0, tk.END)
        self.entry_tipo.delete(0, tk.END)
        self.entry_artesao.delete(0, tk.END)
        self.entry_quantidade.delete(0, tk.END)
        self.entry_codigo.delete(0, tk.END)

    def voltar(self):
        self.master.destroy() 
        self.tela_Loja.master.deiconify()

if __name__ == "__main__":
    root = ctk.CTk()
    try:
        app = TelaLoja(root)
    except Exception as e:
        print(f"Erro ao iniciar a aplicação: {e}")
    root.mainloop()

