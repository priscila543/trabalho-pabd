import tkinter as tk 
from tkinter import messagebox
import sys
import os 
import customtkinter

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.FuncionarioLojaBanco import FuncionarioLojaBanco

customtkinter.set_appearance_mode("dark") 
customtkinter.set_default_color_theme("dark-blue")

class TelaFuncionarioLoja:
    def __init__(self, master):
        self.master = master
        self.master.title("Funcionário da Loja")
        self.FuncionarioLoja_banco = FuncionarioLojaBanco() 

        self.label_username = tk.Label(master, text="Username:")
        self.label_username.grid(row=0, column=0, padx=5, pady=5)
        self.entry_username = tk.Entry(master) 
        self.entry_username.grid(row=0, column=1, padx=5, pady=5)

        self.label_senha = tk.Label(master, text="Senha:")
        self.label_senha.grid(row=1, column=0, padx=5, pady=5)
        self.entry_senha = tk.Entry(master, show='*')  
        self.entry_senha.grid(row=1, column=1, padx=5, pady=5)

        self.button_Login = tk.Button(master, text="Login", command=self.fazer_Login)
        self.button_Login.grid(row=2, columnspan=2, pady=5)

        self.button_Loja = tk.Button(master, text="Abrir Loja", state=tk.DISABLED, command=self.abrindo_tela_Loja)
        self.button_Loja.grid(row=3, columnspan=2, pady=5)

    def fazer_Login(self):
        username = self.entry_username.get()
        senha = self.entry_senha.get()

        FuncionarioLoja = self.FuncionarioLoja_banco.get_FuncionarioLoja_by_username(username)

        if FuncionarioLoja and FuncionarioLoja.senha == senha:
            messagebox.showinfo("Sucesso", "Login realizado com sucesso!")
            self.button_Loja.config(state=tk.NORMAL) 
        else:
            messagebox.showerror("Erro", "Username ou senha incorretos.")

    def abrindo_tela_Loja(self):
        print("Abrindo TelaLoja")  
        self.master.withdraw()
        self.new_window = tk.Toplevel(self.master)
        
        from frontend.TelaLoja import TelaLoja  
        TelaLoja(self.new_window)
        self.new_window.protocol("WM_DELETE_WINDOW", self.voltar)

    def voltar(self):
        self.master.deiconify()

if __name__ == "__main__":
    root = tk.Tk()
    app = TelaFuncionarioLoja(root)
    root.mainloop()
