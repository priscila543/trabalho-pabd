import tkinter as tk
import psycopg2
from tkinter import messagebox
import sys
import os
import customtkinter as ctk

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.LojaBanco import LojaBanco 
from frontend.TelaHome import TelaHome 

ctk.set_appearance_mode("dark") 
ctk.set_default_color_theme("dark-blue")

class TelaLoja:
    def __init__(self, root):
        self.root = root
        self.root.title("Gerenciador de Lojas")

        self.Loja_banco = LojaBanco()
        self.Loja_banco.criar_tabela_Loja() 

        self.setup_widgets()
        self.atualizar_lista_Lojas()

    def setup_widgets(self):
        self.label_id = ctk.CTkLabel(self.root, text="ID da Loja:")
        self.label_id.grid(row=0, column=0, pady=5)

        self.entry_id = ctk.CTkEntry(self.root)  
        self.entry_id.grid(row=0, column=1, pady=5)

        self.label_nome = ctk.CTkLabel(self.root, text="Nome da Loja:")
        self.label_nome.grid(row=1, column=0, pady=5)

        self.entry_nome = ctk.CTkEntry(self.root)
        self.entry_nome.grid(row=1, column=1, pady=5)

        self.label_crm = ctk.CTkLabel(self.root, text="CRM do Funcionário:")
        self.label_crm.grid(row=2, column=0, pady=5)

        self.entry_crm = ctk.CTkEntry(self.root)
        self.entry_crm.grid(row=2, column=1, pady=5)

        self.label_cod = ctk.CTkLabel(self.root, text="Código da Joia:")
        self.label_cod.grid(row=3, column=0, pady=5)

        self.entry_cod = ctk.CTkEntry(self.root)
        self.entry_cod.grid(row=3, column=1, pady=5)

        self.button_cadastrar = ctk.CTkButton(self.root, text="Cadastrar loja", command=self.cadastrar_Loja)
        self.button_cadastrar.grid(row=4, columnspan=2, pady=10)

        self.listbox_Lojas = tk.Listbox(self.root)
        self.listbox_Lojas.grid(row=5, columnspan=2, pady=5)

        self.button_joias = ctk.CTkButton(self.root, text="Acessar Joias", command=self.abrir_tela_Joia)
        self.button_joias.grid(row=6, columnspan=2, pady=5)

    
    def criar_tabela_Loja(self):
        conn = self.conectar_db()
        if conn is None:
            print("Conexão falhou. A tabela não será criada.")
            return

        try:
            with conn:
                with conn.cursor() as cursor:
                    create_Loja_table = '''
                    CREATE TABLE IF NOT EXISTS Loja (
                        id SERIAL PRIMARY KEY,  
                        nome VARCHAR(100) NOT NULL,
                        crm_funcionarioLoja INT REFERENCES FuncionarioLoja(CRM),
                        codigo_Joia INT REFERENCES Joia(cod)
                    );
                    '''
                    cursor.execute(create_Loja_table)
                    print("Tabela Loja criada com sucesso.")
        except Exception as e:
            print(f"Erro ao criar tabela: {e}")
        finally:
            conn.close()

    def cadastrar_Loja(self):
        id = self.entry_id.get()
        nome = self.entry_nome.get()
        crm_funcionario = self.entry_crm.get()
        cod_joia = self.entry_cod.get()

        if not all([id, nome, crm_funcionario, cod_joia]):
            messagebox.showwarning("Atenção", "Preencha todos os campos.")
            return

        if not (id.isdigit() and crm_funcionario.isdigit() and cod_joia.isdigit()):
            messagebox.showwarning("Atenção", "ID, CRM e Código da Joia devem ser numéricos.")
            return

        if self.Loja_banco.verifica_Loja_existente(nome, crm_funcionario, cod_joia):
            messagebox.showwarning("Atenção", "Loja já cadastrada.")
            return

        try:
            self.Loja_banco.inserir_dados(int(id), nome, int(crm_funcionario), int(cod_joia))
            self.atualizar_lista_Lojas()
            self.limpar_campos()
            messagebox.showinfo("Sucesso", "Loja cadastrada com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao cadastrar Loja: {e}")

    def atualizar_lista_Lojas(self):
        self.listbox_Lojas.delete(0, tk.END)
        try:
            for loja in self.Loja_banco.get_all_Lojas():
                id_loja, nome_loja = loja[0], loja[1]
                self.listbox_Lojas.insert(tk.END, f"ID: {id_loja}, Nome: {nome_loja}")
        except Exception as e:
            print(f"Erro ao atualizar a lista das lojas: {e}")

    def abrir_tela_Joia(self):
        selected_index = self.listbox_Lojas.curselection()
        if not selected_index:
            messagebox.showwarning("Atenção", "Selecione uma Loja antes de acessar as Joias.")
            return
        
        selected_loja = self.listbox_Lojas.get(selected_index)
        try:
            id_loja = int(selected_loja.split(",")[0].split(":")[1].strip())
        except (IndexError, ValueError) as e:
            messagebox.showerror("Erro", "A loja selecionada não contém um ID válido.")
            return

        loja = self.Loja_banco.get_all_Lojas()
        for l in loja:
            if l[0] == id_loja:  
                nome_loja = l[1]
                crm_funcionario = l[2]
                codigo_joia = l[3] if len(l) > 3 else None  

                self.abrir_nova_tela_joia(id_loja, nome_loja, crm_funcionario, codigo_joia)
                return

        messagebox.showwarning("Atenção", "Loja não encontrada.")


    def abrindo_tela_Home():
        print("Abrindo TelaHome")
        janela.withdraw()  
        new_window = tk.Toplevel(janela)  
        from frontend.TelaHome import TelaHome  
        TelaHome(new_window)
        new_window.protocol("WM_DELETE_WINDOW", lambda: voltar(janela))
     
        janela = ctk.CTk() 
        janela.geometry("590x300")
        janela.title("Tela Home")
        
        def voltar(master):
            master.deiconify()

    def get_all_Lojas(self):
        conn = self.conectar_db()
        if conn is None:
            return []
        
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM Loja;")
                return cursor.fetchall() 
        except Exception as e:
            print(f"Erro ao obter Lojas: {e}")
            return []
        finally:
            conn.close()

    def abrir_nova_tela_joia(self, id_loja, nome_loja, crm_funcionario, codigo_joia):
        self.new_window = ctk.CTkToplevel(self.root)
        self.new_window.title(f"Joias da {nome_loja}")

        label_info = ctk.CTkLabel(self.new_window, text=f"Loja: {nome_loja}\nid: {id_loja}\nCRM: {crm_funcionario}\nCódigo da Joia: {codigo_joia}")
        label_info.pack(pady=20)

        button_TelaHome = ctk.CTkButton(self.new_window, text="Ir para Tela Home", command=self.abrir_tela_home)
        button_TelaHome.pack(pady=10)

    def limpar_campos(self):
        self.entry_id.delete(0, tk.END)
        self.entry_nome.delete(0, tk.END)
        self.entry_crm.delete(0, tk.END)
        self.entry_cod.delete(0, tk.END)

    def abrir_tela_home(self):
        self.new_window = ctk.CTkToplevel(self.root)
        self.new_window.title("Tela Home")
        TelaHome(self.new_window)

if __name__ == "__main__":
    root = ctk.CTk()
    try:
        app = TelaLoja(root)
    except Exception as e:
        print(f"Erro ao iniciar a aplicação: {e}")
    root.mainloop()
