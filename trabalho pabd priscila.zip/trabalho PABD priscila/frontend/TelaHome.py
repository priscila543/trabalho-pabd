import tkinter as tk
import sys
import os
import customtkinter as ctk

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.JoiaBanco import JoiaBanco

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

janela = ctk.CTk()
janela.geometry("590x300")
janela.title("Tela de Login")

class TelaHome:
    def __init__(self, root):
        self.root = root
        self.joia_banco = JoiaBanco()  
        self.setup_ui()

    def setup_ui(self):
        label = ctk.CTkLabel(self.root, text="Seja bem-vindo")
        label.pack(pady=20)

        button_cadastrar = ctk.CTkButton(self.root, text="Cadastrar Joia", command=self.open_new_window)
        button_cadastrar.pack(pady=10)

        button_acessar_joias = ctk.CTkButton(self.root, text="Acessar Joias", command=self.open_joias_window)
        button_acessar_joias.pack(pady=10)

    def open_new_window(self):
        self.run()

    def open_joias_window(self):
        self.run_joias()

    def run(self):
        global textbNome, textbQuantidade, textbTipo, textbCodigo, textbArtesao, listbox 

        mywindow2 = tk.Toplevel()
        mywindow2.geometry("800x400")
        mywindow2.title("Cadastro de Joia")

        listbox = tk.Listbox(mywindow2)
        self.complete_lista_tipo_Joia()
        listbox.grid(row=0, column=0)

        button = ctk.CTkButton(mywindow2, text='Cadastrar Joia', command=lambda: self.buttonPress())
        button.grid(row=0, column=1)

        textbNome = ctk.CTkEntry(mywindow2, placeholder_text="Nome")
        textbNome.grid(row=1, column=1)

        textbQuantidade = ctk.CTkEntry(mywindow2, placeholder_text="Quantidade")
        textbQuantidade.grid(row=2, column=1)

        textbTipo = ctk.CTkEntry(mywindow2, placeholder_text="Tipo")
        textbTipo.grid(row=3, column=1)

        textbCodigo = ctk.CTkEntry(mywindow2, placeholder_text="Código")
        textbCodigo.grid(row=4, column=1)

        textbArtesao = ctk.CTkEntry(mywindow2, placeholder_text="Artesão")
        textbArtesao.grid(row=5, column=1)

    def run_joias(self):
        mywindow_joias = tk.Toplevel()
        mywindow_joias.geometry("800x400")
        mywindow_joias.title("Lista de Joias")

        listbox_joias = tk.Listbox(mywindow_joias)
        lista_joias = self.joia_banco.get_all_Joia() 
        for joia in lista_joias:
            listbox_joias.insert(tk.END, f"{joia.nome} - {joia.tipo} - {joia.quantidade}")

        listbox_joias.pack(pady=20)

    def buttonPress(self):
        nome = textbNome.get()
        quantidade = textbQuantidade.get()
        tipo = textbTipo.get()
        codigo = textbCodigo.get()
        artesao = textbArtesao.get()

        try:
            self.joia_banco.insert_new_Joia(nome, quantidade, tipo, codigo, artesao)
            self.complete_lista_tipo_Joia()
        except Exception as e:
            print(f"Erro ao cadastrar joia: {e}")

    def complete_lista_tipo_Joia(self):
        lista_Joias_banco_dados = self.joia_banco.get_all_Joia()  
        lista_tipo_Joia = sorted([joia.get_tipo() for joia in lista_Joias_banco_dados], reverse=True)
        listbox.delete(0, tk.END)
        for nome in lista_tipo_Joia:
            listbox.insert(tk.END, nome)

if __name__ == "__main__":
    root = ctk.CTk()
    try:
        app = TelaHome(root)
    except Exception as e:
        print(f"Erro ao iniciar a aplicação: {e}")
    root.mainloop()